using UnityEngine;

public class Zombie : MonoBehaviour
{


}
