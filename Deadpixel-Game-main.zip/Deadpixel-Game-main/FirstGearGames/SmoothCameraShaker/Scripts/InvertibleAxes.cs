﻿namespace FirstGearGames.SmoothCameraShaker
{
    [System.Serializable, System.Flags]
    public enum InvertibleAxes : int
    {
        X = 1,
        Y = 2,
        Z = 4
    }
}